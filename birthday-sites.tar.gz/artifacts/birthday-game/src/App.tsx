import { useEffect, useRef, useState, useCallback } from "react";
import Phaser from "phaser";
import { ForestScene } from "./game/ForestScene";
import { BirthdayScene } from "./game/BirthdayScene";
import { store, type Item, type DialogLine, type RiddleConfig, type GameEvent } from "./game/store";
import "./game.css";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

/* ── Store hook ── */
function useGameStore() {
  const [state, setState] = useState({
    dialog: null as { lines: DialogLine[]; riddle?: RiddleConfig; onComplete?: () => void } | null,
    hint: null as string | null,
    inventory: [] as Item[],
    scene: "forest" as "forest" | "birthday",
    gameComplete: false,
  });
  useEffect(() => store.on((e: GameEvent) => {
    setState((prev) => {
      switch (e.type) {
        case "DIALOG_OPEN":  return { ...prev, dialog: { lines: e.lines, riddle: e.riddle, onComplete: e.onComplete } };
        case "DIALOG_CLOSE": return { ...prev, dialog: null };
        case "HINT_SHOW":    return { ...prev, hint: e.text };
        case "HINT_HIDE":    return { ...prev, hint: null };
        case "INVENTORY_UPDATE": return { ...prev, inventory: e.items };
        case "SCENE_BIRTHDAY":   return { ...prev, scene: "birthday" };
        case "GAME_COMPLETE":    return { ...prev, gameComplete: true };
        default: return prev;
      }
    });
  }), []);
  return state;
}

/* ── Dialog ── */
function DialogBox({ dialog, onClose }: {
  dialog: { lines: DialogLine[]; riddle?: RiddleConfig; onComplete?: () => void };
  onClose: () => void;
}) {
  const [idx, setIdx] = useState(0);
  const [displayed, setDisplayed] = useState("");
  const [done, setDone] = useState(false);
  const [riddleAnswer, setRiddleAnswer] = useState("");
  const [riddleError, setRiddleError] = useState(false);
  const [showRiddle, setShowRiddle] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const audioCtx = useRef<AudioContext | null>(null);
  const line = dialog.lines[idx];

  const blip = useCallback(() => {
    try {
      if (!audioCtx.current) audioCtx.current = new AudioContext();
      const ctx = audioCtx.current;
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.connect(g); g.connect(ctx.destination);
      osc.frequency.value = line.portrait === "kostka" ? 210 : line.portrait === "forester" ? 270 : 330;
      osc.type = "square";
      g.gain.setValueAtTime(0.035, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.055);
      osc.start(); osc.stop(ctx.currentTime + 0.055);
    } catch { /**/ }
  }, [line.portrait]);

  useEffect(() => {
    setDisplayed(""); setDone(false); setShowRiddle(false);
    let i = 0;
    const text = line.text;
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      i++;
      setDisplayed(text.slice(0, i));
      if (i % 2 === 0) blip();
      if (i >= text.length) {
        clearInterval(timerRef.current!);
        setDone(true);
        if (idx === dialog.lines.length - 1 && dialog.riddle)
          setTimeout(() => { setShowRiddle(true); setTimeout(() => inputRef.current?.focus(), 80); }, 350);
      }
    }, 28);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [idx, line.text, blip, dialog.lines.length, dialog.riddle]);

  const skipOrNext = () => {
    if (!done) {
      if (timerRef.current) clearInterval(timerRef.current);
      setDisplayed(line.text); setDone(true);
      if (idx === dialog.lines.length - 1 && dialog.riddle)
        setTimeout(() => { setShowRiddle(true); setTimeout(() => inputRef.current?.focus(), 80); }, 200);
      return;
    }
    if (idx < dialog.lines.length - 1) { setIdx(idx + 1); return; }
    if (!dialog.riddle) { dialog.onComplete?.(); onClose(); }
  };

  const submitRiddle = () => {
    const r = dialog.riddle!;
    if (riddleAnswer.trim().toLowerCase() === r.answer.toLowerCase()) {
      setShowRiddle(false); onClose(); r.onSuccess();
    } else {
      setRiddleError(true);
      setTimeout(() => { setRiddleError(false); setRiddleAnswer(""); setShowRiddle(false); onClose(); r.onFail(); }, 900);
    }
  };

  const portrait = line.portrait;
  const portraitEmoji = portrait === "kostka" ? "👮" : portrait === "forester" ? "🌲" : "🧑";

  return (
    <div className="dialog-overlay">
      <div className="dialog-box">
        <div className="dialog-inner">
          {portrait !== "none" && (
            <div className={`portrait portrait-${portrait}`}>
              <span className="portrait-emoji">{portraitEmoji}</span>
              <div className="portrait-name">
                {portrait === "piotrek" ? "Piotrek" : portrait === "kostka" ? "Pan Kostka" : "Leśnik"}
              </div>
            </div>
          )}
          <div className="dialog-text-area">
            {line.speaker && <div className="dialog-speaker">{line.speaker}</div>}
            <div className="dialog-text">
              {displayed.split("\n").map((l, i, arr) => (
                <span key={i}>{l}{i < arr.length - 1 && <br />}</span>
              ))}
              {done && !showRiddle && <span className="dialog-cursor">▼</span>}
            </div>
          </div>
        </div>

        {showRiddle && (
          <div className="riddle-area">
            <div className="riddle-q">Twoja odpowiedź:</div>
            <input
              ref={inputRef} autoFocus
              className={`riddle-input ${riddleError ? "riddle-err" : ""}`}
              value={riddleAnswer}
              onChange={(e) => setRiddleAnswer(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") submitRiddle(); }}
              placeholder="wpisz..."
            />
            <button className="riddle-btn" onClick={submitRiddle}>OK</button>
          </div>
        )}

        <div className="dialog-footer">
          <button className="d-btn" onClick={() => idx > 0 && setIdx(idx - 1)} disabled={idx === 0}>◀</button>
          {!showRiddle && (
            <button className="d-btn primary" onClick={skipOrNext}>
              {!done ? "Pomiń" : idx < dialog.lines.length - 1 ? "Dalej ▶" : dialog.riddle ? "Zagadka" : "OK ✓"}
            </button>
          )}
          <div className="d-page">{idx + 1}/{dialog.lines.length}</div>
        </div>
      </div>
    </div>
  );
}

/* ── Inventory ── */
function InventoryUI({ items, onDrop }: { items: Item[]; onDrop: (id: string) => void }) {
  return (
    <div className="inv">
      {Array.from({ length: 5 }).map((_, i) => {
        const item = items[i];
        return (
          <div key={i} className={`inv-slot ${item ? "has-item" : ""}`} title={item?.name}>
            {item
              ? <button className="inv-btn" onClick={() => onDrop(item.id)}>{item.emoji}</button>
              : <span className="inv-empty" />}
          </div>
        );
      })}
    </div>
  );
}

/* ── Joystick ── */
function Joystick({ side, label, onMove, onTap }: {
  side: "left" | "right"; label: string;
  onMove?: (x: number, y: number) => void; onTap?: () => void;
}) {
  const outerRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const active = useRef<number | null>(null);
  const center = useRef({ x: 0, y: 0 });
  const R = 38;

  const reset = () => {
    if (knobRef.current) knobRef.current.style.transform = "translate(-50%,-50%)";
    onMove?.(0, 0);
  };

  const onStart = (e: React.TouchEvent) => {
    e.preventDefault();
    const t = e.changedTouches[0];
    active.current = t.identifier;
    const rect = outerRef.current!.getBoundingClientRect();
    center.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    if (side === "right") onTap?.();
  };

  const onMove2 = (e: React.TouchEvent) => {
    e.preventDefault();
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier !== active.current) continue;
      const dx = t.clientX - center.current.x;
      const dy = t.clientY - center.current.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const clamp = Math.min(dist, R);
      const nx = (dx / (dist || 1)) * clamp;
      const ny = (dy / (dist || 1)) * clamp;
      if (knobRef.current) knobRef.current.style.transform = `translate(calc(-50% + ${nx}px), calc(-50% + ${ny}px))`;
      onMove?.(dx / R, dy / R);
    }
  };

  const onEnd = (e: React.TouchEvent) => {
    e.preventDefault();
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier === active.current) { active.current = null; reset(); break; }
    }
  };

  return (
    <div ref={outerRef} className={`joy joy-${side}`}
      onTouchStart={onStart} onTouchMove={onMove2} onTouchEnd={onEnd} onTouchCancel={onEnd}>
      <div ref={knobRef} className="joy-knob">{label}</div>
    </div>
  );
}

/* ── Birthday end buttons ── */
function BirthdayEnd({ onExit, onContinue }: { onExit: () => void; onContinue: () => void }) {
  const [vis, setVis] = useState(false);
  useEffect(() => { const t = setTimeout(() => setVis(true), 2800); return () => clearTimeout(t); }, []);
  if (!vis) return null;
  return (
    <div className="bday-end">
      <button className="bday-btn exit-btn" onClick={onExit}>🚪 Wróć do strony</button>
      <button className="bday-btn cont-btn" onClick={onContinue}>Wróć do strony ▶</button>
    </div>
  );
}

/* ── Root App ── */
export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Phaser.Game | null>(null);
  const sceneRef = useRef<ForestScene | null>(null);
  const { dialog, hint, inventory, scene, gameComplete } = useGameStore();
  const [birthdayReady, setBirthdayReady] = useState(false);
  const [exited, setExited] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;
    const game = new Phaser.Game({
      type: Phaser.AUTO,
      width: window.innerWidth,
      height: window.innerHeight,
      parent: containerRef.current,
      backgroundColor: "#2e7d32",
      physics: { default: "arcade", arcade: { debug: false } },
      scene: [ForestScene, BirthdayScene],
      scale: { mode: Phaser.Scale.RESIZE, autoCenter: Phaser.Scale.CENTER_BOTH },
    });
    gameRef.current = game;
    game.events.on("ready", () => {
      sceneRef.current = game.scene.getScene("ForestScene") as ForestScene;
    });
    return () => { game.destroy(true); gameRef.current = null; };
  }, []);

  useEffect(() => {
    if (scene === "birthday" && gameRef.current) {
      gameRef.current.scene.stop("ForestScene");
      gameRef.current.scene.start("BirthdayScene");
      setBirthdayReady(true);
    }
  }, [scene]);

  const closeDialog = useCallback(() => store.emit({ type: "DIALOG_CLOSE" }), []);
  const handleDrop = (id: string) => sceneRef.current?.removeItem(id);
  const handleJoyMove = (x: number, y: number) => {
    (window as Record<string, number>)["JOY_X"] = x;
    (window as Record<string, number>)["JOY_Y"] = y;
  };
  const handleJoyAction = () => { (window as Record<string, boolean>)["JOY_ACT"] = true; };
  const questUrl = BASE + "/?done=1";

  if (exited) {
    return (
      <div className="result-screen">
        <div className="result-text">🎉 Gratulacje, znalazłeś sekretny przycisk i skończyłeś misję! 🎉</div>
        <button className="result-btn" onClick={() => { window.location.href = BASE + "/?done=1"; }}>Wróć do strony</button>
      </div>
    );
  }

  return (
    <div className="game-root">
      <div ref={containerRef} className="game-canvas" />

      {dialog && <DialogBox dialog={dialog} onClose={closeDialog} />}

      {hint && !dialog && (
        <div className="mc-hint">
          <span className="mc-hint-text">{hint}</span>
          <button className="mc-e-btn" onClick={() => { (window as Record<string, boolean>)["JOY_ACT"] = true; }}>E</button>
        </div>
      )}

      {!dialog && <InventoryUI items={inventory} onDrop={handleDrop} />}

      {birthdayReady && !dialog && (
        <BirthdayEnd onExit={() => { window.location.href = questUrl; }} onContinue={() => { window.location.href = questUrl; }} />
      )}

      <div className="joysticks">
        <Joystick side="left" label="🕹" onMove={handleJoyMove} />
        <Joystick side="right" label="⚡" onTap={handleJoyAction} />
      </div>

      <div className="kbd-hint">WASD / ↑↓←→ ruch &nbsp;·&nbsp; E akcja</div>
    </div>
  );
}
