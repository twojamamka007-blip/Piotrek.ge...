/* ── Background music (C418 - Key from Minecraft Volume Alpha) ── */
let bgAudio: HTMLAudioElement | null = null;
let bgStarted = false;

const MUSIC_URL =
  "https://archive.org/download/minecraft-volume-alpha/C418%20-%20Key.mp3";

function tryPlay() {
  if (!bgAudio || bgStarted) return;
  bgAudio
    .play()
    .then(() => { bgStarted = true; })
    .catch(() => { /* autoplay blocked — wait for interaction */ });
}

export function startMusic() {
  if (bgAudio) { tryPlay(); return; }
  bgAudio = new Audio(MUSIC_URL);
  bgAudio.loop = true;
  bgAudio.volume = 0.18;
  bgAudio.preload = "auto";

  tryPlay();

  /* Retry on first user interaction (mobile / strict browsers) */
  const onInteraction = () => {
    tryPlay();
    if (bgStarted) {
      document.removeEventListener("pointerdown", onInteraction);
      document.removeEventListener("touchstart", onInteraction);
      document.removeEventListener("keydown", onInteraction);
    }
  };
  document.addEventListener("pointerdown", onInteraction);
  document.addEventListener("touchstart", onInteraction);
  document.addEventListener("keydown", onInteraction);
}

export function stopMusic() {
  if (bgAudio) { bgAudio.pause(); bgAudio.currentTime = 0; }
  bgStarted = false;
}

/* ── SFX via Web Audio API ── */
let audioCtx: AudioContext | null = null;

function ctx(): AudioContext {
  if (!audioCtx) audioCtx = new AudioContext();
  if (audioCtx.state === "suspended") audioCtx.resume();
  return audioCtx;
}

function tone(
  hz: number, t: number, dur: number,
  vol = 0.07, type: OscillatorType = "sine"
) {
  try {
    const c = ctx();
    const osc = c.createOscillator();
    const gain = c.createGain();
    osc.connect(gain); gain.connect(c.destination);
    osc.type = type;
    osc.frequency.value = hz;
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(vol, t + 0.015);
    gain.gain.setValueAtTime(vol, t + dur * 0.4);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.start(t); osc.stop(t + dur + 0.05);
  } catch { /**/ }
}

export function playEat() {
  try {
    const c = ctx(); const now = c.currentTime;
    for (let i = 0; i < 4; i++) {
      const osc = c.createOscillator(); const g = c.createGain();
      osc.connect(g); g.connect(c.destination);
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(700 - i * 90, now + i * 0.07);
      osc.frequency.exponentialRampToValueAtTime(320 - i * 30, now + i * 0.07 + 0.07);
      g.gain.setValueAtTime(0.09, now + i * 0.07);
      g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.07 + 0.09);
      osc.start(now + i * 0.07); osc.stop(now + i * 0.07 + 0.12);
    }
  } catch { /**/ }
}

export function playLaugh() {
  try {
    const c = ctx(); const now = c.currentTime;
    [[320, 420], [340, 450], [360, 480]].forEach(([lo, hi], i) => {
      const t = now + i * 0.27;
      const osc = c.createOscillator(); const g = c.createGain();
      osc.connect(g); g.connect(c.destination);
      osc.type = "sine";
      osc.frequency.setValueAtTime(lo, t);
      osc.frequency.linearRampToValueAtTime(hi, t + 0.12);
      osc.frequency.linearRampToValueAtTime(lo * 0.95, t + 0.24);
      g.gain.setValueAtTime(0.18, t);
      g.gain.setValueAtTime(0.14, t + 0.12);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.26);
      osc.start(t); osc.stop(t + 0.3);
    });
  } catch { /**/ }
}

export function playCelebration() {
  try {
    const c = ctx(); const now = c.currentTime;
    const run: [number, number, number][] = [
      [523,0.00,0.18],[587,0.18,0.18],[659,0.36,0.18],
      [698,0.54,0.18],[784,0.72,0.40],[880,1.12,0.25],[1047,1.37,0.70],
    ];
    run.forEach(([hz, off, dur]) => {
      tone(hz, now + off, dur, 0.13, "square");
      tone(hz * 0.5, now + off, dur, 0.06, "sine");
    });
    [523, 659, 784, 1047].forEach((hz) => tone(hz, now + 1.8, 1.8, 0.07, "sine"));
    [523, 659, 784].forEach((hz) => {
      const osc = c.createOscillator(); const g = c.createGain();
      osc.connect(g); g.connect(c.destination);
      osc.type = "triangle"; osc.frequency.value = hz;
      g.gain.setValueAtTime(0, now + 1.8);
      g.gain.linearRampToValueAtTime(0.06, now + 2.0);
      g.gain.exponentialRampToValueAtTime(0.001, now + 4.5);
      osc.start(now + 1.8); osc.stop(now + 4.6);
    });
  } catch { /**/ }
}
