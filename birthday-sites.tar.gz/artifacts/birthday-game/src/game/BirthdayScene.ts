import Phaser from "phaser";
import { store } from "./store";
import { playCelebration, stopMusic } from "./sound";

const S = 4;

function px(
  scene: Phaser.Scene,
  key: string,
  art: string[],
  pal: Record<string, number>,
  sc = S
) {
  const w = art[0].length * sc;
  const h = art.length * sc;
  const g = scene.add.graphics();
  art.forEach((row, y) =>
    [...row].forEach((ch, x) => {
      const c = pal[ch];
      if (c !== undefined) {
        g.fillStyle(c, 1);
        g.fillRect(x * sc, y * sc, sc, sc);
      }
    })
  );
  g.generateTexture(key, w, h);
  g.destroy();
}

const SKIN = [0xffd5aa, 0xf0c090, 0xffccbc, 0xd4a574, 0xc68642];
const TOPS = [0xff4081, 0x40c4ff, 0x69f0ae, 0xff6d00, 0xea80fc, 0xffd700, 0x26c6da, 0xef5350];
const HAIR = [0x3e2723, 0x212121, 0xffd54f, 0xe65100, 0x5d4037, 0x311b92, 0x33691e, 0xbdbdbd];

/* Build a seated person sprite: head + body, no legs visible (sitting) */
function buildPerson(scene: Phaser.Scene, key: string, skin: number, top: number, hair: number) {
  const sk = skin; const tp = top; const hr = hair;
  px(scene, key, [
    ".HHH.", "HHHHH", "SSSSS", "SeSeS",
    "SSSSS", "TTTTT", "TTTTT",
  ], { H: hr, S: sk, e: 0x2c1800, T: tp, ".": -1 }, S);
}

/* Happy raised-arm variant */
function buildPersonHappy(scene: Phaser.Scene, key: string, skin: number, top: number, hair: number) {
  const sk = skin; const tp = top; const hr = hair;
  px(scene, key, [
    ".HHH.", "HHHHH", "SSSSS", "SeSeS",
    "SSSSS", "TTOTT", "TOTOT",
  ], { H: hr, S: sk, e: 0x2c1800, T: tp, O: sk, ".": -1 }, S);
}

const PEOPLE = [
  { skin: SKIN[0], top: TOPS[0], hair: HAIR[0] },
  { skin: SKIN[1], top: TOPS[1], hair: HAIR[1] },
  { skin: SKIN[2], top: TOPS[2], hair: HAIR[2] },
  { skin: SKIN[3], top: TOPS[3], hair: HAIR[3] },
  { skin: SKIN[4], top: TOPS[4], hair: HAIR[4] },
  { skin: SKIN[0], top: TOPS[5], hair: HAIR[5] },
  { skin: SKIN[1], top: TOPS[6], hair: HAIR[6] },
  { skin: SKIN[2], top: TOPS[7], hair: HAIR[7] },
];

export class BirthdayScene extends Phaser.Scene {
  constructor() { super("BirthdayScene"); }

  preload() {
    PEOPLE.forEach((p, i) => {
      buildPerson(this, `person_${i}`, p.skin, p.top, p.hair);
      buildPersonHappy(this, `person_h_${i}`, p.skin, p.top, p.hair);
    });
  }

  create() {
    const W = this.scale.width;
    const H = this.scale.height;

    stopMusic();
    playCelebration();

    /* ── Background warm room ── */
    const bg = this.add.graphics();
    bg.fillGradientStyle(0xfff8e1, 0xfff8e1, 0xffe0b2, 0xffe0b2, 1);
    bg.fillRect(0, 0, W, H);

    /* Wallpaper grid */
    bg.lineStyle(1, 0xf9a825, 0.18);
    for (let x = 0; x < W; x += 48) bg.lineBetween(x, 0, x, H * 0.75);
    for (let y = 0; y < H * 0.75; y += 48) bg.lineBetween(0, y, W, y);

    /* Floor */
    bg.fillStyle(0xd7ccc8, 1);
    bg.fillRect(0, H * 0.73, W, H * 0.27);
    bg.lineStyle(2, 0xbcaaa4, 0.5);
    for (let x = 0; x < W; x += 64) bg.lineBetween(x, H * 0.73, x, H);

    /* ── Streamers ── */
    const streamCols = [0xff4081, 0x40c4ff, 0x69f0ae, 0xffd700, 0xff6d00, 0xea80fc];
    const sg = this.add.graphics();
    for (let i = 0; i < 24; i++) {
      const x1 = (i / 23) * W;
      const x2 = x1 + 60 * Math.sin(i * 0.8);
      const c = Phaser.Display.Color.HexStringToColor(
        "#" + streamCols[i % streamCols.length].toString(16).padStart(6, "0")
      );
      sg.lineStyle(3, c.color, 0.85);
      sg.lineBetween(x1, 0, x2, H * 0.45 + Math.sin(i) * 40);
    }

    /* ── Balloons ── */
    const bCols = [0xff4081, 0x40c4ff, 0x69f0ae, 0xffd700, 0xff6d00, 0xea80fc, 0x26c6da, 0xef5350];
    bCols.forEach((col, i) => {
      const bx = 60 + (i / (bCols.length - 1)) * (W - 120) + Math.sin(i * 1.3) * 20;
      const by = 40 + Math.sin(i * 0.9) * 30;
      sg.fillStyle(col, 0.9);
      sg.fillEllipse(bx, by, 38, 50);
      sg.fillStyle(0xffffff, 0.25);
      sg.fillEllipse(bx - 7, by - 10, 11, 15);
      sg.lineStyle(1, col, 0.5);
      sg.lineBetween(bx, by + 26, bx + Math.sin(i) * 8, H * 0.73);
    });

    /* ── Table ── */
    const tableW = Math.min(W * 0.68, 520);
    const tableH = 28;
    const tableX = (W - tableW) / 2;
    const tableY = H * 0.58;

    const tg = this.add.graphics();
    tg.fillStyle(0x8d6e63, 1);
    tg.fillRoundedRect(tableX - 8, tableY + tableH, tableW + 16, 14, 4); /* legs strip */
    tg.fillStyle(0xa1887f, 1);
    tg.fillRoundedRect(tableX, tableY, tableW, tableH, 6); /* table top */
    tg.fillStyle(0xbcaaa4, 0.5);
    tg.fillRoundedRect(tableX + 4, tableY + 4, tableW - 8, 6, 3); /* highlight */

    /* Plates & food on table */
    const plateSlots = 6;
    for (let i = 0; i < plateSlots; i++) {
      const px2 = tableX + 36 + (i / (plateSlots - 1)) * (tableW - 72);
      const py2 = tableY + tableH / 2;
      tg.fillStyle(0xffffff, 0.9);
      tg.fillEllipse(px2, py2, 28, 14);
      tg.fillStyle(0xef9a9a, 0.8);
      tg.fillEllipse(px2, py2, 18, 9);
    }

    /* Cake center */
    const cakeX = W / 2;
    const cakeY = tableY - 2;
    this.drawCake(tg, cakeX, cakeY);

    /* ── People around table ── */
    const seatCount = PEOPLE.length;
    const sprites: Phaser.GameObjects.Image[] = [];

    for (let i = 0; i < seatCount; i++) {
      let sx: number, sy: number;
      if (i < 4) {
        /* top row — seated above/behind table */
        sx = tableX + 36 + (i / 3) * (tableW - 72);
        sy = tableY - 28;
      } else {
        /* bottom row — seated in front of table */
        sx = tableX + 36 + ((i - 4) / (seatCount - 4 - 1)) * (tableW - 72);
        sy = tableY + tableH + 52;
      }
      const sp = this.add.image(sx, sy, `person_${i}`).setOrigin(0.5, 1).setScale(1);
      sprites.push(sp);

      /* bounce on arrival */
      this.tweens.add({
        targets: sp,
        y: sy - 8,
        duration: 420 + i * 60,
        yoyo: true,
        repeat: -1,
        ease: "Sine.easeInOut",
        delay: i * 120,
      });
    }

    /* Switch to happy arms after fanfare */
    this.time.delayedCall(1600, () => {
      sprites.forEach((sp, i) => {
        sp.setTexture(`person_h_${i}`);
      });
    });

    /* ── Confetti particles ── */
    const confettiCols = [0xff4081, 0x40c4ff, 0x69f0ae, 0xffd700, 0xff6d00, 0xea80fc];
    confettiCols.forEach((col, ci) => {
      const cg = this.add.graphics();
      cg.fillStyle(col, 1);
      cg.fillRect(0, 0, 8, 8);
      cg.generateTexture(`confetti_${ci}`, 8, 8);
      cg.destroy();
    });

    this.time.delayedCall(300, () => {
      for (let p = 0; p < 60; p++) {
        const ci = p % confettiCols.length;
        const cx = Phaser.Math.Between(0, W);
        const piece = this.add.image(cx, -10, `confetti_${ci}`);
        this.tweens.add({
          targets: piece,
          x: cx + Phaser.Math.Between(-80, 80),
          y: H + 20,
          angle: Phaser.Math.Between(-360, 360),
          duration: Phaser.Math.Between(1200, 2800),
          delay: p * 40,
          ease: "Sine.easeIn",
          onComplete: () => piece.destroy(),
        });
      }
    });

    /* ── Banner ── */
    const banner = this.add.text(W / 2, 52, "🎉 WSZYSTKIEGO NAJLEPSZEGO PIOTREK! 🎉", {
      fontFamily: "monospace",
      fontSize: `${Math.max(14, Math.min(22, W / 24))}px`,
      fontStyle: "bold",
      color: "#ff4081",
      stroke: "#ffffff",
      strokeThickness: 4,
      shadow: { color: "#ff4081", blur: 14, fill: true },
    }).setOrigin(0.5);

    this.tweens.add({
      targets: banner,
      scaleX: 1.05, scaleY: 1.05,
      duration: 650, yoyo: true, repeat: -1, ease: "Sine.easeInOut",
    });

    /* Sub text */
    this.time.delayedCall(800, () => {
      this.add.text(W / 2, H * 0.73 - 24, "Twoi znajomi na Ciebie czekali! 🥳", {
        fontFamily: "monospace",
        fontSize: `${Math.max(11, Math.min(16, W / 36))}px`,
        color: "#795548",
        stroke: "#fff8e1",
        strokeThickness: 3,
      }).setOrigin(0.5).setAlpha(0).setData("tween", true);

      this.add.tween({
        targets: this.children.list[this.children.list.length - 1],
        alpha: 1,
        duration: 700,
        ease: "Sine.easeOut",
      });
    });

    this.time.delayedCall(2200, () => {
      store.emit({ type: "GAME_COMPLETE", result: "exit" });
    });
  }

  private drawCake(g: Phaser.GameObjects.Graphics, x: number, baseY: number) {
    /* three tiers */
    g.fillStyle(0xf48fb1, 1);
    g.fillRoundedRect(x - 44, baseY - 82, 88, 30, 4);
    g.fillStyle(0xfce4ec, 1);
    g.fillRoundedRect(x - 54, baseY - 54, 108, 30, 4);
    g.fillStyle(0xfff9c4, 1);
    g.fillRoundedRect(x - 64, baseY - 26, 128, 28, 4);
    /* frosting drips */
    g.fillStyle(0xffffff, 0.85);
    for (let i = 0; i < 6; i++) {
      g.fillEllipse(x - 44 + i * 18, baseY - 52, 14, 10);
    }
    /* candles */
    const candleXs = [x - 28, x - 8, x + 12, x + 32];
    g.fillStyle(0xff8f00, 1);
    candleXs.forEach((cx) => g.fillRect(cx, baseY - 100, 5, 20));
    g.fillStyle(0xffd54f, 1);
    candleXs.forEach((cx) => g.fillEllipse(cx + 2, baseY - 101, 9, 12));
    g.fillStyle(0xffffff, 0.6);
    candleXs.forEach((cx) => g.fillEllipse(cx + 1, baseY - 103, 4, 6));

    this.add.text(x, baseY - 40, "🎂", { fontSize: "22px" }).setOrigin(0.5);
  }
}
