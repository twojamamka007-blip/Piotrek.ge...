import Phaser from "phaser";
import { store, type Item } from "./store";
import * as D from "./dialogs";
import { startMusic, playEat, playLaugh } from "./sound";

/* ── World constants ── */
const WW = 4000;
const WH = 2400;
const PATH_Y = 1200;
const SPEED = 190;
const S = 4; // pixel scale

/* ── Pixel art helper ── */
function px(
  scene: Phaser.Scene,
  key: string,
  art: string[],
  pal: Record<string, number>,
  sc = S
) {
  const w = art[0].length * sc;
  const h = art.length * sc;
  const g = scene.add.graphics();
  art.forEach((row, y) =>
    [...row].forEach((ch, x) => {
      const c = pal[ch];
      if (c !== undefined) {
        g.fillStyle(c, 1);
        g.fillRect(x * sc, y * sc, sc, sc);
      }
    })
  );
  g.generateTexture(key, w, h);
  g.destroy();
}

const PAL: Record<string, number> = {
  B: 0x7b5230, L: 0xa07848, S: 0xffd5aa, e: 0x2c1800,
  m: 0xb04040, C: 0xd0d0d0, k: 0x888888, P: 0x1a3570,
  s: 0x3e2723, G: 0x2e7d32, g: 0x43a047, N: 0x2d6a2d,
  n: 0x388e3c, t: 0x6d4c41, T: 0x5d4037, w: 0x1565c0,
  W: 0x64b5f6, F: 0xef5350, Y: 0xffd54f, r: 0xd32f2f,
  X: 0xffffff, K: 0xc8a882, p: 0xffa726, j: 0xffd700,
  q: 0x4e342e, Z: 0xeeeeee, V: 0x4e9e4e, d: 0x8d6e63,
  M: 0xff8f00, o: 0xff6d00, R: 0xb71c1c,
};

type Obj = { x: number; y: number; range: number; action: string; onInteract: () => void };

export class ForestScene extends Phaser.Scene {
  private player!: Phaser.Physics.Arcade.Sprite;
  private trees!: Phaser.Physics.Arcade.StaticGroup;
  private objs: Obj[] = [];
  private hintObj: Obj | null = null;

  private inventory: Item[] = [];
  private dialogActive = false;
  private kostkaRiddleDone = false;
  private foresterMet = false;
  private trapHit = false;
  private berriesGone = false;
  private treasureGone = false;
  private treeSpriteAt: Phaser.GameObjects.Sprite | null = null;
  private berrySprite!: Phaser.GameObjects.Sprite;
  private treasureSprite!: Phaser.GameObjects.Sprite;
  private kostkaSprite!: Phaser.GameObjects.Sprite;

  private direction: "down" | "up" | "left" | "right" = "down";
  private walkFrame = 0;
  private walkTimer = 0;
  private eKey!: Phaser.Input.Keyboard.Key;
  private cursors!: Phaser.Types.Input.Keyboard.CursorKeys;
  private wasd!: Record<string, Phaser.Input.Keyboard.Key>;
  private fishTimer = 0;
  private decorGraphics!: Phaser.GameObjects.Graphics;

  constructor() {
    super("ForestScene");
  }

  preload() {
    this.buildTextures();
  }

  private buildTextures() {
    /* ── Player – front (down) ── */
    px(this, "p_d1", [
      "..LLBB..", ".BBBBBB.", ".SSSSSS.", ".SeSSe..",
      ".SSuSSS.", ".CCCCCC.", ".CkCCCC.", ".CCCCCC.",
      ".PPPPPP.", ".PP..PP.", ".ss..ss.",
    ], { ...PAL, u: 0xd32f2f });
    px(this, "p_d2", [
      "..LLBB..", ".BBBBBB.", ".SSSSSS.", ".SeSSe..",
      ".SSuSSS.", ".CCCCCC.", ".CkCCCC.", ".CCCCCC.",
      ".PPPPPP.", "..PP.PP.", "..ss.ss.",
    ], { ...PAL, u: 0xd32f2f });

    /* ── Player – back (up) ── */
    px(this, "p_u1", [
      "..BBBB..", ".BBBBBB.", ".BBBBBBB", "BBBBBBBB",
      ".CCCCCC.", ".CCCCCC.", ".CkCCCC.", ".CCCCCC.",
      ".PPPPPP.", ".PP..PP.", ".ss..ss.",
    ], PAL);
    px(this, "p_u2", [
      "..BBBB..", ".BBBBBB.", ".BBBBBBB", "BBBBBBBB",
      ".CCCCCC.", ".CCCCCC.", ".CkCCCC.", ".CCCCCC.",
      ".PPPPPP.", "..PP.PP.", "..ss.ss.",
    ], PAL);

    /* ── Player – left/right (side) ── */
    px(this, "p_l1", [
      ".BBBBB..", ".BBBBBB.", "SSSSBBB.", "SeSSSS..",
      "SSSSSSS.", "SmSSSSS.", "CCCCCCC.", "CkCCCCC.",
      "CCCCCCC.", ".PPPPP..", "PP....PP", "ss....ss",
    ], { ...PAL, u: 0xd32f2f });
    px(this, "p_l2", [
      ".BBBBB..", ".BBBBBB.", "SSSSBBB.", "SeSSSS..",
      "SSSSSSS.", "SmSSSSS.", "CCCCCCC.", "CkCCCCC.",
      "CCCCCCC.", ".PPPPP..", ".PP..PP.", ".ss..ss.",
    ], { ...PAL, u: 0xd32f2f });

    /* ── Tree canopy (top-down) ── */
    px(this, "tree", [
      "...NNNN...", "..NNNNNNN.", ".NNNnnNNN.", ".NNnnnnNN.",
      "NNNnnnnNNN", "NNNnnnnNNN", ".NNnnnnNN.", ".NNNNNNN..",
      "..NNNNN...", "....ttt....",
    ], PAL, 5);

    /* ── Bush ── */
    px(this, "bush", [
      "..GG..", ".GGGG.", "GGGGGG", "GGGGGG", ".GGGG.", "..GG..",
    ], PAL, 5);

    /* ── Berries ── */
    px(this, "berry", [
      "..G...", ".GGG..", "FFFFFF", "FFFFFF", ".FFFF.", "......"
    ], PAL, 4);

    /* ── Flower (decorative) ── */
    px(this, "flower_y", [".YY.", "YYYY", "YYYY", ".YY."], PAL, 3);
    px(this, "flower_r", [".FF.", "FFFF", "FFFF", ".FF."], { ...PAL, F: 0xff4081 }, 3);
    px(this, "flower_w", [".XX.", "XXXX", "XXXX", ".XX."], PAL, 3);

    /* ── Rock ── */
    px(this, "rock", [
      "..KKK..", ".KKKKK.", "KKKKKKK", "KKKKKKK", ".KKKKK.", "...KK...",
    ], { ...PAL, K: 0x9e9e9e }, 4);

    /* ── Mushroom ── */
    px(this, "shroom", [
      ".RRR.", "RRRRR", "RRRRR", ".XXX.", ".XXX.",
    ], PAL, 4);

    /* ── Chest ── */
    px(this, "chest", [
      ".tttttttttt.", "tYYYYYYYYYYt", "tYYYjYYjYYYt",
      "tttttttttttt", "tTTTTTTTTTTt", "tttttttttttt",
    ], PAL, 4);

    /* ── Trap ── */
    px(this, "trap", [
      "ooooooooo", "o.......o", "o.ooooo.o",
      "o.......o", "ooooooooo",
    ], PAL, 4);

    /* ── Sign ── */
    px(this, "sign", [
      "..tt..", "..tt..", "XXXXXX", "XXXXXZ", "XXXXXX", "..tt..", "..tt..",
    ], { ...PAL, Z: 0xbbbbbb }, 5);

    /* ── Bench ── */
    px(this, "bench", ["tttttttttttt", "tttttttttttt", "....tt....tt", "....tt....tt"], PAL, 4);

    /* ── Waterfall splash (top-down) ── */
    px(this, "water_fx", [
      "WWWWWWWWWW", "WwwwwwwwwW", "WwwwwwwwwW", "WWWWWWWWWW",
    ], { ...PAL, W: 0x90caf9, w: 0xbbdefb }, 6);

    /* ── Fish ── */
    px(this, "fish", [".ooo.", ".oooo", "ooooo", ".oooo", ".ooo."], PAL, 3);

    /* ── Axe / chop marker ── */
    px(this, "axe", [
      ".YYY.", "YYYYY", ".YYY.", "..t..", "..t..",
    ], PAL, 5);

    /* ── Hut (top-down) ── */
    px(this, "hut", [
      "rrrrrrrrrrrrrrrrrrrr", "rrrrrrrrrrrrrrrrrrrrr",
      "tttttttttttttttttttt", "tttttttttttttttttttt",
      "tt..tt..tt..dd..tttt", "tt..tt..tt..dd..tttt",
      "tt..tt..tt..tt..tttt", "tttttttttttttttttttt",
    ], PAL, 4);

    /* ── School building ── */
    px(this, "school", [
      "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ",
      "ZZ..ZZ..ZZZZddddddZZZZ..ZZ..ZZZ",
      "ZZ..ZZ..ZZZZddddddZZZZ..ZZ..ZZZ",
      "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ",
      "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ",
    ], PAL, 4);

    /* ── Kostka (guard) ── */
    px(this, "kostka", [
      "..KKKK..", ".KKKKKK.", ".SSSSSS.", ".SeSSe..",
      ".SSSSSS.", ".SmSSSSS", "VVVVVVVV", "VdVdVdVd",
      "VVVVVVVV", ".PPPPPP.", ".PP..PP.", ".ss..ss.",
    ], { ...PAL, K: 0x8d6e63, V: 0x4caf50, d: 0x388e3c });

    /* ── Forester ── */
    px(this, "forester", [
      "..BBBB..", ".BBBBBB.", ".SSSSSS.", ".SeSSe..",
      ".SSSSSS.", ".SmSSSSS", "TTTTTTTT", "TTTTTTTt",
      "TTTTTTTT", ".PPPPPP.", ".PP..PP.", ".ss..ss.",
    ], PAL);

    /* ── Fox / rabbit / squirrel ── */
    px(this, "fox", ["..FF..", "FFFFFF", "FfFFFF", "FFFFFF", "FF..FF"],
      { ...PAL, F: 0xe65100, f: 0xffffff }, 4);
    px(this, "rabbit", [".Z..Z", "..ZZ.", ".ZZZZ", ".ZeZZ", ".ZZZZ"],
      { ...PAL, Z: 0xeeeeee }, 4);
    px(this, "squirrel", ["..BB", "BBB.", "BBBB", "BBbB", "BB.."],
      { ...PAL, b: 0xffd54f }, 4);
  }

  create() {
    startMusic();
    this.physics.world.gravity.y = 0;
    this.physics.world.setBounds(0, 0, WW, WH);

    this.drawWorld();
    this.plantTrees();
    this.placeObjects();
    this.createPlayer();
    this.setupInput();
    this.setupCamera();
    this.scheduleAnimals();

    store.on((e) => {
      if (e.type === "DIALOG_CLOSE") this.dialogActive = false;
    });
  }

  /* ────────────────── World Drawing ────────────────── */

  private drawWorld() {
    const bg = this.add.graphics().setDepth(-20);

    /* Base grass */
    bg.fillStyle(0x43a047, 1);
    bg.fillRect(0, 0, WW, WH);

    /* Grass variation patches */
    const rng = new Phaser.Math.RandomDataGenerator(["forest42"]);
    for (let i = 0; i < 800; i++) {
      const x = rng.between(0, WW);
      const y = rng.between(0, WH);
      bg.fillStyle(rng.pick([0x388e3c, 0x4caf50, 0x2e7d32, 0x558b2f]), 0.6);
      bg.fillRect(x, y, rng.between(8, 40), rng.between(8, 28));
    }

    /* Main horizontal path */
    bg.fillStyle(0x8d6e63, 0.55);
    bg.fillRect(80, PATH_Y - 90, WW - 160, 180);
    bg.fillStyle(0xa1887f, 0.35);
    bg.fillRect(80, PATH_Y - 70, WW - 160, 140);

    /* Path edge grass */
    bg.fillStyle(0x33691e, 0.3);
    for (let x = 80; x < WW - 160; x += 30) {
      bg.fillRect(x + rng.between(-5, 5), PATH_Y - 98, 4, 18);
      bg.fillRect(x + rng.between(-5, 5), PATH_Y + 80, 4, 18);
    }

    /* North branch path (to waterfall) */
    bg.fillStyle(0x8d6e63, 0.5);
    bg.fillRect(950, 320, 160, PATH_Y - 90 - 320);

    /* River */
    bg.fillStyle(0x1565c0, 0.85);
    bg.fillRect(1650, 0, 130, WH);
    bg.fillStyle(0x1976d2, 0.5);
    bg.fillRect(1660, 0, 50, WH);
    bg.fillStyle(0x90caf9, 0.2);
    bg.fillRect(1700, 0, 20, WH);

    /* Bridge */
    bg.fillStyle(0x6d4c41, 1);
    bg.fillRect(1640, PATH_Y - 100, 160, 200);
    bg.fillStyle(0x8d6e63, 1);
    bg.fillRect(1645, PATH_Y - 100, 18, 200);
    bg.fillRect(1770, PATH_Y - 100, 18, 200);

    /* Waterfall spray */
    bg.fillStyle(0x90caf9, 0.7);
    bg.fillEllipse(1030, 350, 220, 120);
    bg.fillStyle(0xbbdefb, 0.9);
    bg.fillEllipse(1030, 350, 140, 70);

    /* Waterfall source (dark rock face) */
    bg.fillStyle(0x546e7a, 1);
    bg.fillRect(900, 240, 270, 90);
    bg.fillStyle(0x607d8b, 1);
    bg.fillRect(920, 255, 230, 60);

    /* Hut clearing */
    bg.fillStyle(0x6a994b, 0.5);
    bg.fillEllipse(2150, 920, 420, 280);

    /* School courtyard */
    bg.fillStyle(0x8d6e63, 0.4);
    bg.fillRect(3050, 1050, 600, 380);

    /* Decorative flowers (random) */
    this.decorGraphics = this.add.graphics().setDepth(-8);
    const flowerPositions: Array<{ x: number; y: number; col: number }> = [];
    for (let i = 0; i < 120; i++) {
      const fx = rng.between(100, WW - 100);
      const fy = rng.between(100, WH - 100);
      if (this.isOnPath(fx, fy)) continue;
      flowerPositions.push({ x: fx, y: fy, col: rng.pick([0xffd54f, 0xff4081, 0xffffff, 0xffa726]) });
    }
    flowerPositions.forEach(({ x, y, col }) => {
      this.decorGraphics.fillStyle(col, 0.85);
      this.decorGraphics.fillCircle(x, y, 5);
      this.decorGraphics.fillStyle(0xffff8d, 0.7);
      this.decorGraphics.fillCircle(x, y, 2);
    });

    /* Rocks */
    for (let i = 0; i < 40; i++) {
      const rx = rng.between(200, WW - 200);
      const ry = rng.between(200, WH - 200);
      if (this.isOnPath(rx, ry)) continue;
      const rockG = this.add.graphics().setDepth(-7);
      rockG.fillStyle(0x9e9e9e, 1);
      rockG.fillEllipse(rx, ry, rng.between(14, 32), rng.between(10, 22));
      rockG.fillStyle(0xbdbdbd, 0.5);
      rockG.fillEllipse(rx - 4, ry - 4, 8, 5);
    }

    /* Mushrooms */
    for (let i = 0; i < 25; i++) {
      const mx = rng.between(200, WW - 200);
      const my = rng.between(200, WH - 200);
      if (this.isOnPath(mx, my)) continue;
      const mG = this.add.graphics().setDepth(-7);
      mG.fillStyle(rng.pick([0xb71c1c, 0xe64a19, 0x880e4f]), 1);
      mG.fillEllipse(mx, my - 4, 16, 12);
      mG.fillStyle(0xffffff, 0.5);
      mG.fillCircle(mx - 3, my - 6, 2);
      mG.fillStyle(0xfff9c4, 1);
      mG.fillRect(mx - 3, my - 1, 6, 8);
    }
  }

  private isOnPath(x: number, y: number): boolean {
    /* Main path */
    if (y > PATH_Y - 110 && y < PATH_Y + 110 && x > 80 && x < WW - 80) return true;
    /* North branch */
    if (x > 940 && x < 1120 && y > 300 && y < PATH_Y - 90) return true;
    /* Hut clearing */
    if (Phaser.Math.Distance.Between(x, y, 2150, 920) < 220) return true;
    /* School area */
    if (x > 3050 && x < 3700 && y > 1040 && y < 1460) return true;
    return false;
  }

  /* ────────────────── Trees ────────────────── */

  private plantTrees() {
    this.trees = this.physics.add.staticGroup();
    const rng = new Phaser.Math.RandomDataGenerator(["trees99"]);

    const attempt = (x: number, y: number, sc = 1) => {
      if (this.isOnPath(x, y)) return;
      /* Don't block objects */
      const tooClose = this.objs.some(o => Phaser.Math.Distance.Between(x, y, o.x, o.y) < 90);
      if (tooClose) return;
      const spr = this.add.sprite(x, y, "tree").setDepth(2).setScale(sc);
      /* Invisible collider */
      const body = this.physics.add.staticImage(x, y + 10, undefined as unknown as string)
        .setVisible(false);
      body.setDisplaySize(28 * sc, 28 * sc);
      (body.body as Phaser.Physics.Arcade.StaticBody).setSize(28 * sc, 28 * sc);
      this.trees.add(body as unknown as Phaser.GameObjects.GameObject);
      /* Shadow */
      const shadow = this.add.graphics().setDepth(1);
      shadow.fillStyle(0x000000, 0.12);
      shadow.fillEllipse(x + 10, y + 22, 50 * sc, 20 * sc);
    };

    /* Dense north forest */
    for (let tx = 0; tx < WW; tx += 110) {
      for (let ty = 0; ty < 800; ty += 100) {
        attempt(tx + rng.between(-20, 20), ty + rng.between(-20, 20), rng.realInRange(0.85, 1.25));
      }
    }
    /* Dense south forest */
    for (let tx = 0; tx < WW; tx += 110) {
      for (let ty = 1700; ty < WH; ty += 100) {
        attempt(tx + rng.between(-20, 20), ty + rng.between(-20, 20), rng.realInRange(0.85, 1.25));
      }
    }
    /* Scattered mid forest */
    for (let i = 0; i < 200; i++) {
      attempt(rng.between(200, WW - 200), rng.between(800, 1600), rng.realInRange(0.8, 1.2));
    }
  }

  /* ────────────────── Objects ────────────────── */

  private addObj(x: number, y: number, key: string, action: string, cb: () => void, range = 95) {
    const spr = this.add.sprite(x, y, key).setDepth(3);
    const shadow = this.add.graphics().setDepth(2);
    shadow.fillStyle(0x000000, 0.15);
    shadow.fillEllipse(x + 6, y + spr.height / 2 + 4, spr.width * 0.9, 14);
    this.objs.push({ x, y, range, action, onInteract: cb });
    return spr;
  }

  private placeObjects() {
    /* Spawn sign */
    this.addObj(280, PATH_Y, "sign", "Czytaj tablicę", () => this.openDialog(D.SIGN_SPAWN));

    /* Direction sign 1 */
    this.addObj(550, PATH_Y - 40, "sign", "Czytaj drogowskaz", () => this.openDialog(D.SIGN_DIRECTION));

    /* Berries */
    this.berrySprite = this.addObj(720, PATH_Y - 140, "berry", "Zjedz jagody", () => this.pickBerries());

    /* Bench */
    this.addObj(900, PATH_Y + 60, "bench", "Usiądź na ławce", () => this.openDialog(D.BENCH_SIT));

    /* Waterfall — north branch */
    this.addObj(1030, 370, "water_fx", "Podziwiaj wodospad", () => this.openDialog(D.WATERFALL), 110);

    /* Fish in river */
    this.add.sprite(1685, PATH_Y - 40, "fish").setDepth(1).setAlpha(0.8);
    this.add.sprite(1695, PATH_Y + 20, "fish").setDepth(1).setAlpha(0.8);
    this.objs.push({ x: 1685, y: PATH_Y - 20, range: 105, action: "Patrz na ryby", onInteract: () => this.openDialog(D.RIVER) });

    /* Trap */
    this.addObj(1320, PATH_Y + 230, "trap", "⚠ Podejdź bliżej", () => this.hitTrap(), 80);

    /* Treasure */
    this.treasureSprite = this.addObj(1350, PATH_Y - 230, "chest", "Otwórz skrzynię", () => this.getSecretTreasure());

    /* Chopping tree */
    this.add.sprite(1850, PATH_Y - 200, "tree").setDepth(2).setScale(1.1);
    this.objs.push({ x: 1850, y: PATH_Y - 200, range: 100, action: "Ścinaj drzewo", onInteract: () => this.chopTree() });

    /* Direction sign 2 */
    this.addObj(2000, PATH_Y + 50, "sign", "Czytaj drogowskaz", () => this.openDialog(D.SIGN_DIRECTION));

    /* Hut */
    this.add.sprite(2150, 920, "hut").setDepth(2);
    this.objs.push({ x: 2150, y: 920, range: 130, action: "Wejdź do chaty", onInteract: () => this.meetForester() });

    /* Forester */
    this.kostkaSprite = this.add.sprite(2260, 1000, "forester").setDepth(3) as unknown as Phaser.GameObjects.Sprite;
    this.objs.push({ x: 2260, y: 1000, range: 95, action: "Porozmawiaj z leśnikiem", onInteract: () => this.talkForester() });

    /* Pan Kostka */
    this.kostkaSprite = this.add.sprite(3080, PATH_Y, "kostka").setDepth(3);
    this.objs.push({ x: 3080, y: PATH_Y, range: 110, action: "Porozmawiaj z Panem Kostką", onInteract: () => this.talkKostka() });

    /* School */
    this.add.sprite(3400, PATH_Y - 20, "school").setDepth(2);
    this.add.text(3400, PATH_Y - 120, "2 Liceum Ogólnokształcące", {
      fontFamily: "monospace", fontSize: "14px", color: "#000",
      backgroundColor: "#ffffffcc", padding: { x: 6, y: 3 },
    }).setOrigin(0.5, 1).setDepth(5);
    this.objs.push({ x: 3400, y: PATH_Y - 20, range: 130, action: "Wejdź do szkoły", onInteract: () => this.enterSchool() });
  }

  /* ────────────────── Player ────────────────── */

  private createPlayer() {
    this.player = this.physics.add.sprite(220, PATH_Y, "p_d1");
    this.player.setDepth(10);
    this.player.setCollideWorldBounds(true);
    this.player.body!.setSize(20, 20);
    this.physics.add.collider(this.player, this.trees);
  }

  private setupInput() {
    this.cursors = this.input.keyboard!.createCursorKeys();
    this.eKey = this.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.E);
    this.wasd = {
      W: this.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.W),
      A: this.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.A),
      S: this.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.S),
      D: this.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.D),
    };
  }

  private setupCamera() {
    this.cameras.main.setBounds(0, 0, WW, WH);
    this.cameras.main.startFollow(this.player, true, 0.08, 0.08);
    this.cameras.main.setZoom(1.6);
  }

  /* ────────────────── Game Loop ────────────────── */

  update(_: number, delta: number) {
    if (this.dialogActive) return;

    const jx: number = (window as Record<string, number>)["JOY_X"] ?? 0;
    const jy: number = (window as Record<string, number>)["JOY_Y"] ?? 0;
    const jAction: boolean = (window as Record<string, boolean>)["JOY_ACT"] ?? false;

    const left  = this.cursors.left.isDown  || this.wasd.A.isDown || jx < -0.25;
    const right = this.cursors.right.isDown || this.wasd.D.isDown || jx > 0.25;
    const up    = this.cursors.up.isDown    || this.wasd.W.isDown || jy < -0.25;
    const down  = this.cursors.down.isDown  || this.wasd.S.isDown || jy > 0.25;
    const eDown = Phaser.Input.Keyboard.JustDown(this.eKey) || jAction;

    const body = this.player.body as Phaser.Physics.Arcade.Body;

    let vx = 0, vy = 0;
    if (left)  vx -= SPEED;
    if (right) vx += SPEED;
    if (up)    vy -= SPEED;
    if (down)  vy += SPEED;

    /* Analog stick */
    if (Math.abs(jx) > 0.25) vx = jx * SPEED;
    if (Math.abs(jy) > 0.25) vy = jy * SPEED;

    /* Normalize diagonal */
    if (vx !== 0 && vy !== 0) { vx *= 0.707; vy *= 0.707; }
    body.setVelocity(vx, vy);

    /* Direction + texture */
    const moving = vx !== 0 || vy !== 0;
    if (moving) {
      if (Math.abs(vx) >= Math.abs(vy)) {
        this.direction = vx > 0 ? "right" : "left";
      } else {
        this.direction = vy > 0 ? "down" : "up";
      }
      this.walkTimer += delta;
      if (this.walkTimer > 170) {
        this.walkTimer = 0;
        this.walkFrame = (this.walkFrame + 1) % 2;
      }
    } else {
      this.walkFrame = 0;
    }
    this.applyPlayerTexture();

    /* Interaction */
    this.findNear();
    if (eDown && this.hintObj) {
      this.hintObj.onInteract();
    }
    (window as Record<string, boolean>)["JOY_ACT"] = false;

    /* Fish jump */
    this.fishTimer += delta;
    if (this.fishTimer > 3800) {
      this.fishTimer = 0;
      this.doFishJump();
    }
  }

  private applyPlayerTexture() {
    const f = this.walkFrame;
    switch (this.direction) {
      case "down":  this.player.setTexture(f ? "p_d2" : "p_d1").setFlipX(false); break;
      case "up":    this.player.setTexture(f ? "p_u2" : "p_u1").setFlipX(false); break;
      case "left":  this.player.setTexture(f ? "p_l2" : "p_l1").setFlipX(false); break;
      case "right": this.player.setTexture(f ? "p_l2" : "p_l1").setFlipX(true);  break;
    }
  }

  private findNear() {
    const px = this.player.x, py = this.player.y;
    let best: Obj | null = null, bestD = Infinity;
    for (const o of this.objs) {
      const d = Phaser.Math.Distance.Between(px, py, o.x, o.y);
      if (d < o.range && d < bestD) { bestD = d; best = o; }
    }
    if (best !== this.hintObj) {
      this.hintObj = best;
      store.emit(best ? { type: "HINT_SHOW", text: best.action } : { type: "HINT_HIDE" });
    }
  }

  /* ────────────────── Object Interactions ────────────────── */

  private openDialog(lines: typeof D.SIGN_SPAWN, onDone?: () => void) {
    this.dialogActive = true;
    store.emit({ type: "DIALOG_OPEN", lines, onComplete: onDone });
  }

  private pickBerries() {
    if (this.berriesGone) {
      this.openDialog([{ speaker: "Piotrek", text: "Jagody już zjedzone.", portrait: "piotrek" }]);
      return;
    }
    if (this.inventory.length >= 5) {
      this.openDialog([{ speaker: "Piotrek", text: "Plecak pełny!", portrait: "piotrek" }]); return;
    }
    this.berriesGone = true;
    this.berrySprite.setAlpha(0.3);
    this.addItem({ id: "berries", name: "Jagody", emoji: "🫐" });
    this.openDialog(D.BERRIES_EAT);
  }

  private hitTrap() {
    if (this.trapHit) { this.openDialog([{ speaker: "Piotrek", text: "Omijam pułapkę.", portrait: "piotrek" }]); return; }
    this.trapHit = true;
    this.cameras.main.shake(600, 0.022);
    this.openDialog(D.TRAP_CAUGHT);
  }

  private getSecretTreasure() {
    if (this.treasureGone) { this.openDialog([{ speaker: "Piotrek", text: "Skrzynka pusta.", portrait: "piotrek" }]); return; }
    if (this.inventory.length >= 5) { this.openDialog([{ speaker: "Piotrek", text: "Plecak pełny!", portrait: "piotrek" }]); return; }
    this.treasureGone = true;
    this.treasureSprite.setAlpha(0.35);
    this.addItem({ id: "coin", name: "Złota moneta", emoji: "🪙" });
    this.openDialog(D.TREASURE);
  }

  private chopTree() {
    if (this.inventory.length >= 5) { this.openDialog([{ speaker: "Piotrek", text: "Plecak pełny!", portrait: "piotrek" }]); return; }
    this.addItem({ id: "wood", name: "Drewno", emoji: "🪵" });
    this.cameras.main.shake(300, 0.012);
    this.openDialog(D.TREE_CHOP);
  }

  private meetForester() {
    this.openDialog(D.FORESTER_HELLO, () => { this.foresterMet = true; });
  }

  private talkForester() {
    if (!this.foresterMet) { this.meetForester(); return; }
    this.openDialog(D.FORESTER_WATER, () => {
      if (this.inventory.length < 5) this.addItem({ id: "water", name: "Szklanka wody", emoji: "🥤" });
    });
  }

  private talkKostka() {
    if (this.kostkaRiddleDone) {
      this.openDialog([{ speaker: "Pan Kostka", text: "No dawaj, wchodź już!", portrait: "kostka" }]); return;
    }
    this.dialogActive = true;
    store.emit({
      type: "DIALOG_OPEN",
      lines: [...D.KOSTKA_INTRO, ...D.KOSTKA_RIDDLE_QUESTION],
      riddle: {
        question: "Jak nazywa się pszczoła bez czoła?",
        answer: "psz",
        onSuccess: () => {
          this.kostkaRiddleDone = true;
          playLaugh();
          this.time.delayedCall(150, () => this.openDialog(D.KOSTKA_SUCCESS));
        },
        onFail: () => {
          this.time.delayedCall(150, () =>
            this.openDialog(D.KOSTKA_RIDDLE_WRONG, () =>
              this.time.delayedCall(200, () => this.talkKostka())
            )
          );
        },
      },
    });
  }

  private enterSchool() {
    if (!this.kostkaRiddleDone) {
      this.openDialog([{ speaker: "Pan Kostka", text: "Stój! Najpierw rozwiąż zagadkę!", portrait: "kostka" }]); return;
    }
    this.openDialog(D.SCHOOL_ENTER, () => {
      this.cameras.main.fade(1000, 0, 0, 0);
      this.time.delayedCall(1200, () => store.emit({ type: "SCENE_BIRTHDAY" }));
    });
  }

  private addItem(item: Item) {
    if (this.inventory.length >= 5) return;
    this.inventory = [...this.inventory, item];
    store.emit({ type: "INVENTORY_UPDATE", items: this.inventory });
    playEat();
  }

  removeItem(id: string) {
    this.inventory = this.inventory.filter((i) => i.id !== id);
    store.emit({ type: "INVENTORY_UPDATE", items: this.inventory });
  }

  private doFishJump() {
    const spr = this.add.sprite(1680, PATH_Y - 10, "fish").setDepth(6);
    this.tweens.add({ targets: spr, y: PATH_Y - 60, duration: 380, ease: "Sine.easeOut", yoyo: true, onComplete: () => spr.destroy() });
  }

  /* ────────────────── Animals ────────────────── */

  private scheduleAnimals() {
    this.time.addEvent({
      delay: Phaser.Math.Between(7000, 13000),
      callback: () => { if (!this.dialogActive) this.spawnAnimal(); this.scheduleAnimals(); },
    });
  }

  private spawnAnimal() {
    const types = ["fox", "rabbit", "squirrel"];
    const key = types[Math.floor(Math.random() * types.length)];
    const camX = this.cameras.main.scrollX, camY = this.cameras.main.scrollY;
    const fromLeft = Math.random() < 0.5;
    const sx = fromLeft ? camX - 60 : camX + 900;
    const sy = camY + Phaser.Math.Between(80, 640);
    const tx = fromLeft ? camX + 960 : camX - 60;
    const spr = this.add.sprite(sx, sy, key).setDepth(8).setFlipX(!fromLeft);
    this.tweens.add({ targets: spr, x: tx, duration: Phaser.Math.Between(1600, 2800), ease: "Linear", onComplete: () => spr.destroy() });
    this.tweens.add({ targets: spr, y: sy - 8, duration: 280, yoyo: true, repeat: 8, ease: "Sine.easeInOut" });
  }
}
