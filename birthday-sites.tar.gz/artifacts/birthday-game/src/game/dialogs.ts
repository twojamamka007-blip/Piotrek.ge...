import type { DialogLine } from "./store";

export const SIGN_SPAWN: DialogLine[] = [
  { speaker: "", text: "[ TABLICA STARTOWA ]", portrait: "none" },
  { speaker: "", text: "Witaj wędrowcze! Twoim zadaniem jest znaleźć\n2 Liceum Ogólnokształcące ukryte w tym lesie.", portrait: "none" },
  { speaker: "", text: "Możesz zbierać przedmioty do plecaka (max 5).\nUżyj [E] lub prawego joysticka, by wchodzić w interakcje.", portrait: "none" },
];

export const SIGN_DIRECTION: DialogLine[] = [
  { speaker: "", text: "[ DROGOWSKAZ ]", portrait: "none" },
  { speaker: "", text: "→ Do szkoły: 2 km\n↑ Wodospad: 200 m\n← Wyjście z lasu", portrait: "none" },
];

export const BENCH_SIT: DialogLine[] = [
  { speaker: "Piotrek", text: "Ahhh, wreszcie chwila odpoczynku!", portrait: "piotrek" },
  { speaker: "Piotrek", text: "Ten las jest naprawdę piękny. Ale muszę znaleźć tę szkołę...", portrait: "piotrek" },
];

export const WATERFALL: DialogLine[] = [
  { speaker: "Piotrek", text: "Wow! Piękny wodospad!", portrait: "piotrek" },
  { speaker: "Piotrek", text: "Słyszę jak woda uderza w kamienie...\nBardzo relaksujące.", portrait: "piotrek" },
];

export const RIVER: DialogLine[] = [
  { speaker: "Piotrek", text: "Przejrzysta rzeczka. Widzę ryby pływające w wodzie.", portrait: "piotrek" },
  { speaker: "Piotrek", text: "O! Jedna wyskoczyła! To chyba szczupak!", portrait: "piotrek" },
];

export const BERRIES_LOOK: DialogLine[] = [
  { speaker: "Piotrek", text: "Krzak jagód! Wyglądają bardzo smacznie.", portrait: "piotrek" },
  { speaker: "Piotrek", text: "Mogę je zjeść albo zabrać do plecaka.", portrait: "piotrek" },
];

export const BERRIES_EAT: DialogLine[] = [
  { speaker: "Piotrek", text: "Mniam! Świeże leśne jagody. Pyszne!", portrait: "piotrek" },
];

export const TRAP_CAUGHT: DialogLine[] = [
  { speaker: "Piotrek", text: "AAAAAA! PUŁAPKA!!!", portrait: "piotrek" },
  { speaker: "Piotrek", text: "Uff... to tylko sieć myśliwska.\nUdało mi się wyjść. Trzeba uważać!", portrait: "piotrek" },
];

export const TREASURE: DialogLine[] = [
  { speaker: "Piotrek", text: "Stara drewniana skrzynka! To SKARB!", portrait: "piotrek" },
  { speaker: "Piotrek", text: "W środku jest stara złota moneta.\nBiorę ją do plecaka!", portrait: "piotrek" },
];

export const TREE_CHOP: DialogLine[] = [
  { speaker: "Piotrek", text: "Ścinam drzewo. Mam kawałek drewna!", portrait: "piotrek" },
];

export const FORESTER_HELLO: DialogLine[] = [
  { speaker: "Leśnik", text: "Cześć przybyszu! Co Cię do mojej chaty sprowadza?", portrait: "forester" },
  { speaker: "Piotrek", text: "Szukam 2 Liceum Ogólnokształcące...", portrait: "piotrek" },
  { speaker: "Leśnik", text: "Aaah, ta stara szkoła! Idź prosto na wschód.\nPo drodze trafisz na wartownika - Pana Kostkę.", portrait: "forester" },
  { speaker: "Leśnik", text: "Ostrzegam, jest trochę... ekscentryczny. Ha ha!", portrait: "forester" },
];

export const FORESTER_WATER: DialogLine[] = [
  { speaker: "Piotrek", text: "Masz może szklankę wody? Trochę mi się chce pić.", portrait: "piotrek" },
  { speaker: "Leśnik", text: "Oczywiście! Zawsze mam świeżą wodę źródlaną.", portrait: "forester" },
  { speaker: "Leśnik", text: "Proszę bardzo! Dobra, zimna woda.", portrait: "forester" },
  { speaker: "Piotrek", text: "Dziękuję! Smakuje jak z górskiego źródła.", portrait: "piotrek" },
];

export const KOSTKA_INTRO: DialogLine[] = [
  { speaker: "Pan Kostka", text: "STÓJ! Nikt nie wchodzi bez mojej zgody!", portrait: "kostka" },
  { speaker: "Pan Kostka", text: "Piotrek, to Ty? Chcesz wejść do szkoły?", portrait: "kostka" },
  { speaker: "Pan Kostka", text: "Dobrze... ale najpierw musisz rozwiązać moją zagadkę!", portrait: "kostka" },
];

export const KOSTKA_RIDDLE_QUESTION: DialogLine[] = [
  { speaker: "Pan Kostka", text: "Słuchaj uważnie...", portrait: "kostka" },
  { speaker: "Pan Kostka", text: "Jak nazywa się pszczoła bez czoła?", portrait: "kostka" },
];

export const KOSTKA_RIDDLE_WRONG: DialogLine[] = [
  { speaker: "Pan Kostka", text: "Hmm... Nie, to nie jest dobra odpowiedź!", portrait: "kostka" },
  { speaker: "Pan Kostka", text: "Spróbuj jeszcze raz! Pomyśl...", portrait: "kostka" },
];

export const KOSTKA_SUCCESS: DialogLine[] = [
  { speaker: "Pan Kostka", text: "Hahahahaha!!! PSZ! Oczywiście!", portrait: "kostka" },
  { speaker: "Pan Kostka", text: "Pszczoła bez CZOŁA... to PSZ! Ha ha ha!", portrait: "kostka" },
  { speaker: "Pan Kostka", text: "No dobra, wchodź! Czeka na Ciebie coś wyjątkowego...", portrait: "kostka" },
];

export const SCHOOL_ENTER: DialogLine[] = [
  { speaker: "Piotrek", text: "Wchodzę do 2 Liceum Ogólnokształcące...", portrait: "piotrek" },
];
