export type Item = {
  id: string;
  name: string;
  emoji: string;
};

export type DialogLine = {
  speaker: string;
  text: string;
  portrait: "piotrek" | "kostka" | "forester" | "none";
};

export type RiddleConfig = {
  question: string;
  answer: string;
  onSuccess: () => void;
  onFail: () => void;
};

export type GameEvent =
  | { type: "DIALOG_OPEN"; lines: DialogLine[]; riddle?: RiddleConfig; onComplete?: () => void }
  | { type: "DIALOG_CLOSE" }
  | { type: "HINT_SHOW"; text: string }
  | { type: "HINT_HIDE" }
  | { type: "INVENTORY_UPDATE"; items: Item[] }
  | { type: "SCENE_BIRTHDAY" }
  | { type: "GAME_COMPLETE"; result: "exit" | "continue" };

type Listener = (event: GameEvent) => void;

class Store {
  private ls = new Set<Listener>();
  emit(e: GameEvent) {
    this.ls.forEach((l) => l(e));
  }
  on(l: Listener) {
    this.ls.add(l);
    return () => this.ls.delete(l);
  }
}

export const store = new Store();
