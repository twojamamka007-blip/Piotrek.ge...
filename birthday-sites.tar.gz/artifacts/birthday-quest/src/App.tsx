import { useState, useEffect, useRef } from "react";
import "./quest.css";

type Stage = "consent" | "riddle" | "screamer" | "rickroll" | "shutdown";

export default function App() {
  const [stage, setStage] = useState<Stage>(() => {
    const p = new URLSearchParams(window.location.search);
    return p.get("done") === "1" ? "rickroll" : "consent";
  });
  const [answer, setAnswer] = useState("");
  const [error, setError] = useState(false);
  const [shutdownSeconds, setShutdownSeconds] = useState(30 * 60);
  const inputRef = useRef<HTMLInputElement>(null);
  const screamerTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const shutdownStartRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const shutdownIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const focusInput = () => {
    inputRef.current?.focus({ preventScroll: true });
  };

  useEffect(() => {
    if (stage === "riddle") {
      setTimeout(() => inputRef.current?.focus({ preventScroll: true }), 100);
    }
  }, [stage]);

  useEffect(() => {
    if (error) {
      const t = setTimeout(() => {
        setError(false);
        inputRef.current?.focus();
      }, 600);
      return () => clearTimeout(t);
    }
  }, [error]);

  useEffect(() => {
    if (stage === "screamer") {
      screamerTimerRef.current = setTimeout(() => {
        setStage("rickroll");
      }, 1200);
    }
    return () => {
      if (screamerTimerRef.current) clearTimeout(screamerTimerRef.current);
    };
  }, [stage]);

  useEffect(() => {
    if (stage === "rickroll") {
      shutdownStartRef.current = setTimeout(() => {
        setStage("shutdown");
        shutdownIntervalRef.current = setInterval(() => {
          setShutdownSeconds((s) => {
            if (s <= 1) {
              clearInterval(shutdownIntervalRef.current!);
              return 0;
            }
            return s - 1;
          });
        }, 1000);
      }, 60 * 60 * 1000);
    }
    return () => {
      if (shutdownStartRef.current) clearTimeout(shutdownStartRef.current);
      if (shutdownIntervalRef.current) clearInterval(shutdownIntervalRef.current);
    };
  }, [stage]);

  const handleAnswer = () => {
    if (answer.toLowerCase() === "austria") {
      setError(false);
      setStage("screamer");
    } else {
      setError(true);
      setAnswer("");
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, "0");
    const s = (secs % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

  return (
    <div className="vhs-body">
      <div className="vhs-overlay" />
      <div className="scanlines" />
      <div className="noise" />

      {stage === "rickroll" && (
        <a href={`${BASE}/game/`} className="game-float-btn" tabIndex={0}>▶ gra</a>
      )}

      {stage === "consent" && (
        <div className="modal-backdrop">
          <div className="modal">
            <div className="modal-title glitch" data-text="⚠ UWAGA ⚠">⚠ UWAGA ⚠</div>
            <p className="modal-text">
              Ta strona wymaga dostępu do następujących zasobów Twojego urządzenia:
            </p>
            <ul className="permission-list">
              <li>📷 Kamera i mikrofon</li>
              <li>📁 Tajny folder systemowy</li>
              <li>💬 Wszystkie Twoje czaty i wiadomości</li>
            </ul>
            <p className="modal-text small">
              Klikając OK, wyrażasz zgodę na powyższe warunki. Odmowa uniemożliwi dostęp do serwisu.
            </p>
            <button className="btn-ok" onClick={() => setStage("riddle")}>
              OK — ZGADZAM SIĘ
            </button>
          </div>
        </div>
      )}

      {stage === "riddle" && (
        <div className="riddle-screen" onClick={focusInput}>
          <div className="riddle-box">
            <div className="riddle-header glitch" data-text="ZAGADKA BEZPIECZEŃSTWA">ZAGADKA BEZPIECZEŃSTWA</div>
            <p className="riddle-question">
              Jaki kraj nie graniczy z Polską?
            </p>
            <p className="riddle-hint">Wpisz odpowiedź (7 liter):</p>
            <div className="input-row" onClick={focusInput}>
              {Array.from({ length: 7 }).map((_, i) => (
                <div
                  key={i}
                  className={`letter-box ${error ? "shake error" : ""} ${i === answer.length && !error ? "active-box" : ""}`}
                  onClick={focusInput}
                >
                  {answer[i] ? answer[i].toUpperCase() : ""}
                </div>
              ))}
            </div>
            <input
              ref={inputRef}
              className="hidden-input"
              maxLength={7}
              value={answer}
              autoFocus
              onChange={(e) => {
                setError(false);
                setAnswer(e.target.value.replace(/[^a-zA-Z]/g, ""));
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleAnswer();
              }}
            />
            {error && <p className="error-text grain-text">BŁĘDNA ODPOWIEDŹ. SPRÓBUJ PONOWNIE.</p>}
            <button
              className="btn-ok"
              onClick={handleAnswer}
              disabled={answer.length < 7}
            >
              POTWIERDŹ
            </button>
          </div>
        </div>
      )}

      {stage === "screamer" && (
        <div className="screamer">
          <div className="red-face" />
        </div>
      )}

      {stage === "rickroll" && (
        <div className="rickroll-screen">
          <div className="rickroll-title glitch" data-text="🎉 GRATULACJE! 🎉">
            🎉 GRATULACJE! 🎉
          </div>
          <div className="video-wrapper">
            <iframe
              src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&controls=0&loop=1&playlist=dQw4w9WgXcQ"
              title="Rick Roll"
              frameBorder="0"
              allow="autoplay; encrypted-media"
              allowFullScreen
            />
          </div>
          <p className="rickroll-sub grain-text">NIGDY NIE ODPUSZCZAMY!</p>
          <a href={`${BASE}/game/`} className="secret-game-btn" tabIndex={0}>▶ gra</a>
        </div>
      )}

      {stage === "shutdown" && (
        <div className="rickroll-screen">
          <div className="rickroll-title glitch" data-text="🎉 GRATULACJE! 🎉">
            🎉 GRATULACJE! 🎉
          </div>
          <div className="video-wrapper">
            <iframe
              src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&controls=0&loop=1&playlist=dQw4w9WgXcQ"
              title="Rick Roll"
              frameBorder="0"
              allow="autoplay; encrypted-media"
              allowFullScreen
            />
          </div>
          <p className="rickroll-sub grain-text">NIGDY NIE ODPUSZCZAMY!</p>
          <div className="shutdown-banner">
            <div className="shutdown-title glitch-red" data-text="⚠ OSTRZEŻENIE SYSTEMOWE ⚠">⚠ OSTRZEŻENIE SYSTEMOWE ⚠</div>
            <p className="shutdown-text">
              Wszystkie dane zostaną usunięte, a telefon zostanie wyłączony za:
            </p>
            <div className="countdown grain-red">{formatTime(shutdownSeconds)}</div>
            {shutdownSeconds === 0 && (
              <div className="shutdown-final glitch-red" data-text="WYŁĄCZANIE...">WYŁĄCZANIE...</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
